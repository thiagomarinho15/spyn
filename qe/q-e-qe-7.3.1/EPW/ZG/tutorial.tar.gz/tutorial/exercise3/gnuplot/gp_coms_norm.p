set terminal pdf color enhanced font "arial,22" size 6.0,4.0
set output "norm.pdf"
set encoding iso_8859_1
set yrange [0:5]
set ylabel "{/Symbol D} || C_{1,1} || (eV / {\305}^2)"
set xlabel "iteration"
set ytics 1
set mytics 2

# set bmargin 2.6

set border lw 6

plot "norm.dat" u 1:(abs($2-0.09969798)*13.6057039763 / 0.529177**2 *sqrt(3)) not pt 5,\
 "norm.dat" u 1:(abs($2-0.09969798)*13.6057039763 / 0.529177**2 *sqrt(3)) not w l lw 3

